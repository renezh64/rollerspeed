package com.rollerspeed.rollerspeed;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RollerspeedApplicationTests {

	@Test
	void contextLoads() {
	}

}
